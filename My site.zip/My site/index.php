<!DOCTYPE html>
<html>
<head>
	<title>QuickTeach</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="text/css" href="images/quick.png">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css2?family=Bitter:wght@700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="JavaScript" href="quiz.js">
</head>
<body>
	<div id="naver">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="index.php"><img class="brandLogo" src="images/quick.png"
        alt="image" height="30px"></a>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">

        <li class="nav-item">
          <a class="nav-link" href="index.php"><i class="fa fa-fw fa-home"></i>Home</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="about.php"><i class="fa fa-fw fa-user"></i>About Us</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="https://www.mindwide.ga/">Blog</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="contact.php"><i class="fa fa-fw fa-envelope"></i>Contact Us</a>
        </li>

   
      </ul>
   
  </div>
</nav>
</div>
<div id="pop">
<h3>Are you bored,no more now because now we are here to take you through some of the best questions and increase your IQ with fun.So,let's start
	</h3>

</div>
<div id="container">
            <h1>Quizer from QuickTeach</h1>
   			<br/>
  			<div id="quiz"></div>
    		<div class="button" id="next"><a href="#">Next</a></div>
    		<div class="button" id="prev"><a href="#">Prev</a></div> 
    	</div>
        <script src="https://code.jquery.com/jquery-3.4.0.min.js"></script>
		<script src="quiz.js"></script>


<div class="py-5">
           <h3 class="text-center">About us</h3>
          </div>
          <div class="container-fluid">
<div class="row">
<div class="col-lg-6 col-md-6 col-12">
	<img src="images/quick.png" class="img-fluid aboutimg" height="800px" width="400px">
</div>
<div class="col-lg-6 col-md-6 col-12">
	<h1 class="display-4">QuickTeach</h1>
  <h4 class="py-5">
      In this site you will be answering questions and increase your IQ with fun because our motive is to learn with fun.
  </h4>
  <a href="about.php" class="btn btn-outline-success-outline-success">Know more</a>
</div>
</div>
</section>

<section class="my-5">

          <div class="py-5">
           <h2 class="text-center">Founder of this site.</h2>
          </div>
          <div class="container-fluid">
<div class="row">
<div class="col-lg-6 col-md-4 col-12">
   <div class="card" >
  <img class="card-img-top" src="images/lak.png" alt="Card image">
  <div class="card-body">
    <h4 class="card-title text-center">Lakshya</h4>
    <p class="card-text text-center">Founder of this site</p>
    </div>
</div>
</div>
</div>
</div>
</section>
</div>

 <section class="my-5">
  <div class="py-5">
           <h2 class="text-center">Contact us</h2>
          </div>
   
   

  <div class="w-50 m-auto">
  <form action="userinfo.php" method ="post">
<div class="form-group">
  <label>Username</label>
  <input type="text" name="User" autocomplete="on" class="form-control"required>
</div>
<div class="form-group">
<label>Email-Id</label>
  <input type="email" name="Email" id="Email"autocomplete="on" class="form-control">

</div>
<div class="form-group">
<label>Mobile</label>
  <input type="Number" name="Mobile" autocomplete="on" class="form-control"required>
</div>
<div class="form-group">
<label>Comments</label>
<textarea cols="form-control" name="comment"required></textarea>

  </div>
<button type="submit" class="btn-outline-success">Submit</button>
</form>
 </div>
 </section>



</body>
<section>
  <h1>© Copyright 2020 </h1>
  
</section>
<div class="footer">
  <div id="button"></div>
<div id="container">
<div id="cont">
<div class="footer_center">
     <h3>QuickTeach</h3>
</div>
</div>
</div>
</div>
</html>
