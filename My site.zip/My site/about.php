<!DOCTYPE html>
<html>
<head>
  <title>About Us-QuickTeach</title>

</head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="text/css" href="images/quick.png">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css2?family=Bitter:wght@700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="about.css">
<body>
<div class="about-section">
  <h1>About Us</h1>
  <h3>Are you bored,no more now because now we are here to take you through some of the best questions and increase your IQ with fun.</h3>
  <h3>In this site you will be answering questions and increase your IQ with fun because our motive is to learn with fun.</h3>
  <h2>
  That's All :)
</h2>
</div>



</body>
</html>