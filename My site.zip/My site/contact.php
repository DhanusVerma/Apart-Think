<!DOCTYPE html>
<html>
<head>
  <title>Contact Us-QuickTeach</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="text/css" href="images/quick.png">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css2?family=Bitter:wght@700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
 
 <section class="my-5">
  <div class="py-5">
           <h2 class="text-center">Contact us</h2>
          </div>
   
   

  <div class="w-50 m-auto">
  <form action="userinfo.php" method ="post">
<div class="form-group">
  <label>Username</label>
  <input type="text" name="User" autocomplete="on" class="form-control"required>
</div>
<div class="form-group">
<label>Email-Id</label>
  <input type="email" name="Email" id="Email"autocomplete="on" class="form-control">

</div>
<div class="form-group">
<label>Mobile</label>
  <input type="Number" name="Mobile" autocomplete="on" class="form-control"required>
</div>
<div class="form-group">
<label>Comments</label>
<textarea cols="form-control" name="comment"required></textarea>

  </div>
<button type="submit" class="btn-outline-success">Submit</button>
</form>
 </div>
 </section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapwcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</body>
</html>